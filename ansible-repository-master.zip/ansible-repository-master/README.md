# ansible-repository

This repository is **DEPRECATED** in favor of [Ansible Devbox](https://github.com/gaspaio/ansible-devbox).

But yes, i am still using Ansible on a daily basis. I decided to rewrite the whole thing using the new Ansible Best Practices and syntax. Also, the new repository is less generic and clearly oriented to development server provisionning.

The Ansible-Repository will stay available for future reference and inspiration.



